// Function to open multiple pop-up windows
function openWindows(count) {
    for (let i = 0; i < count; i++) {
        // Opens a new window with specified dimensions and position
        // Note: Modern browsers often block multiple pop-ups by default.
        window.open(
            'about:blank', // URL of the page to open in the pop-up
            '_blank',
            'height=400,width=350,left=' + (i * 50) + ',top=' + (i * 50) + 
            ',resizable=no,scrollbars=no,toolbar=no,menubar=no,location=no,directories=no,status=no'
        );
    }
}

// Example: call this on a button click
// openWindows(5);